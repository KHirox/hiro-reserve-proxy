import { logger } from '../core/utils/logger.js';

const cacheConfig = {
    redis: {
        url: process.env.REDIS_CACHE_URL || 'redis://localhost:6379/0',
        options: {
            socket: {
                connectTimeout: 5000,
                reconnectStrategy: (retries) => Math.min(retries * 100, 5000)
            }
        }
    },
    defaults: {
        ttl: parseInt(process.env.CACHE_TTL) || 3600, // 1 hour default
        prefix: 'khirox:cache:',
        maxKeys: 10000
    },
    blacklist: [
        '/admin',
        '/config',
        '/.env'
    ]
};

// Validate configuration
if (!cacheConfig.redis.url) {
    logger.error('Cache configuration error: REDIS_CACHE_URL is required');
    process.exit(1);
}

export default cacheConfig;