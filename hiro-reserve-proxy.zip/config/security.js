import { logger } from '../core/utils/logger.js';

const securityConfig = {
    tls: {
        minVersion: 'TLSv1.2',
        ciphers: [
            'TLS_AES_256_GCM_SHA384',
            'TLS_CHACHA20_POLY1305_SHA256',
            'TLS_AES_128_GCM_SHA256'
        ].join(':'),
        honorCipherOrder: true
    },
    rateLimiting: {
        windowMs: (process.env.RATE_LIMIT_WINDOW || 15) * 60 * 1000, // 15 minutes
        max: parseInt(process.env.RATE_LIMIT_MAX) || 100,
        keyGenerator: (req) => req.ip,
        handler: (req, res) => {
            logger.warn(`Rate limit exceeded for IP: ${req.ip}`);
            res.status(429).json({
                error: 'Too many requests',
                retryAfter: (process.env.RATE_LIMIT_WINDOW || 15) * 60
            });
        }
    },
    headers: {
        poweredBy: 'KHirox Proxy Engine',
        hsts: {
            maxAge: 63072000, // 2 years
            includeSubDomains: true,
            preload: true
        },
        cors: {
            origin: '*',
            methods: ['GET', 'OPTIONS'],
            allowedHeaders: ['Content-Type', 'Authorization']
        }
    }
};

export default securityConfig;