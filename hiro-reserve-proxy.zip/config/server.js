import { logger } from '../core/utils/logger.js';
import { readFileSync } from 'fs';
import { join } from 'path';
import { fileURLToPath } from 'url';

const __dirname = fileURLToPath(new URL('.', import.meta.url));

const serverConfig = {
    http: {
        port: parseInt(process.env.PORT) || 88,
        timeout: 120000,
        keepAliveTimeout: 60000
    },
    https: {
        port: parseInt(process.env.HTTPS_PORT) || 444,
        options: {
            key: readFileSync(join(__dirname, '../../certs/_.growplus.asia/cdn.growplus.asia-key.pem')),
            cert: readFileSync(join(__dirname, '../../certs/_.growplus.asia/cdn.growplus.asia-crt.pem')),
            ca: readFileSync(join(__dirname, '../../certs/_.growplus.asia/cdn.growplus.asia-chain.pem')),
            minVersion: 'TLSv1.2',
            requestCert: false,
            rejectUnauthorized: false
        }
    },
    cluster: {
        enabled: process.env.NODE_ENV === 'production',
        workers: process.env.CLUSTER_WORKERS || os.cpus().length
    },
    logging: {
        level: process.env.LOG_LEVEL || 'info',
        file: {
            enabled: process.env.LOG_TO_FILE === 'true',
            path: join(__dirname, '../../logs/proxy.log')
        }
    }
};

// Validate HTTPS certificates
try {
    serverConfig.https.options.key;
    serverConfig.https.options.cert;
} catch (err) {
    logger.error('Failed to load HTTPS certificates', { error: err.message });
    process.exit(1);
}

export default serverConfig;