import { createServer } from 'https';
import { createServer as createHttpServer } from 'http';
import { readFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import app from './app.js';
import { logger } from './core/utils/logger.js';
import serverConfig from '../config/server.js';

const __dirname = dirname(fileURLToPath(import.meta.url));

class ProxyServer {
  constructor() {
    this.httpServer = null;
    this.httpsServer = null;
    this.initializeServers();
    this.setupErrorHandlers();
  }

  initializeServers() {
    try {
      // HTTPS Server
      this.httpsServer = createServer(serverConfig.https.options, app)
        .listen(serverConfig.https.port, () => {
          logger.info(`KHirox HTTPS Server running on port ${serverConfig.https.port}`);
        })
        .on('tlsClientError', (err, socket) => {
          logger.error(`HTTPS TLS Client Error: ${err.message}`);
          socket.end('HTTP/1.1 400 Bad Request\r\n\r\n');
        });

      // HTTP Server (for health checks and redirects)
      this.httpServer = createHttpServer(app)
        .listen(serverConfig.http.port, () => {
          logger.info(`KHirox HTTP Server running on port ${serverConfig.http.port}`);
        });

    } catch (error) {
      logger.error('Server initialization failed', { error: error.message });
      process.exit(1);
    }
  }

  setupErrorHandlers() {
    process.on('unhandledRejection', (err) => {
      logger.error(`Unhandled rejection: ${err.message}`, { stack: err.stack });
    });

    process.on('SIGTERM', this.gracefulShutdown.bind(this));
    process.on('SIGINT', this.gracefulShutdown.bind(this));
  }

  gracefulShutdown() {
    logger.info('Starting graceful shutdown...');
    
    const shutdownPromises = [];
    
    if (this.httpsServer) {
      shutdownPromises.push(new Promise(resolve => {
        this.httpsServer.close(() => {
          logger.info('HTTPS server closed');
          resolve();
        });
      }));
    }

    if (this.httpServer) {
      shutdownPromises.push(new Promise(resolve => {
        this.httpServer.close(() => {
          logger.info('HTTP server closed');
          resolve();
        });
      }));
    }

    Promise.all(shutdownPromises)
      .then(() => {
        logger.info('Shutdown complete');
        process.exit(0);
      })
      .catch(err => {
        logger.error('Error during shutdown', { error: err.message });
        process.exit(1);
      });
  }
}

// Start the server
new ProxyServer();