import express from 'express';
import helmet from 'helmet';
import compression from 'compression';
import morgan from 'morgan';
import { rateLimit } from 'express-rate-limit';
import { RedisStore } from 'rate-limit-redis';
import { createClient } from 'redis';
import securityConfig from '../config/security.js';
import { logger } from './core/utils/logger.js';
import indexRouter from './routes/index.js';
import cacheProxyRouter from './routes/cache-proxy.js';
import { requestLogger } from './middleware/request-logger.js';
import { errorHandler } from './middleware/error-handler.js';

class AppFactory {
  static async create() {
    const app = express();
    
    // Initialize Redis client
    const redisClient = await this.initializeRedis();
    
    // Setup middleware
    this.setupMiddleware(app, redisClient);
    
    // Setup routes
    this.setupRoutes(app);
    
    // Setup error handling
    this.setupErrorHandling(app);
    
    return app;
  }

  static async initializeRedis() {
    try {
      const client = createClient({
        url: process.env.REDIS_URL || 'redis://localhost:6379',
        socket: {
          reconnectStrategy: (attempt) => Math.min(attempt * 100, 5000)
        }
      });
      
      await client.connect();
      logger.info('Redis client connected successfully');
      return client;
    } catch (error) {
      logger.error('Redis connection failed', { error: error.message });
      throw error;
    }
  }

  static setupMiddleware(app, redisClient) {
    // Security headers
    app.use(helmet(securityConfig.helmet));
    
    // Compression
    app.use(compression({ level: 6 }));
    
    // Rate limiting
    const limiter = rateLimit({
      store: new RedisStore({
        sendCommand: (...args) => redisClient.sendCommand(args),
        prefix: 'khirox-rl:'
      }),
      ...securityConfig.rateLimiting
    });
    app.use(limiter);
    
    // Logging
    app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
    app.use(requestLogger);
    
    // Body parsing
    app.use(express.json({ limit: '10kb' }));
    app.use(express.urlencoded({ extended: true, limit: '10kb' }));
  }

  static setupRoutes(app) {
    // API routes
    app.use('/', indexRouter);
    app.use('/:ip/cache/*', cacheProxyRouter);
    
    // 404 handler
    app.use((req, res) => {
      res.status(404).json({
        error: 'Not Found',
        message: 'The requested resource was not found'
      });
    });
  }

  static setupErrorHandling(app) {
    app.use(errorHandler);
  }
}

// Create and export the app instance
export default await AppFactory.create();