import { createClient } from 'redis';
import { logger } from '../utils/logger.js';
import cacheConfig from '../config/cache.js';

class CacheManager {
    constructor() {
        this.client = createClient({
            url: cacheConfig.redis.url,
            socket: {
                connectTimeout: 5000,
                reconnectStrategy: (retries) => {
                    const delay = Math.min(retries * 100, 5000);
                    logger.warn(`Redis reconnecting attempt ${retries}, next try in ${delay}ms`);
                    return delay;
                }
            },
            ...cacheConfig.redis.options
        });

        this.connected = false;
        this.healthy = false;
        
        this.client.on('error', (err) => {
            logger.error('Redis client error', { error: err.message });
            this.healthy = false;
        });
        
        this.client.on('ready', () => {
            this.healthy = true;
            logger.info('Redis client ready');
        });
        
        this.client.on('reconnecting', () => {
            logger.info('Redis client reconnecting...');
        });
    }

    async connect() {
        if (!this.connected) {
            try {
                await this.client.connect();
                this.connected = true;
                this.healthy = true;
                logger.info('CacheManager successfully connected to Redis');
            } catch (error) {
                logger.error('CacheManager connection failed', { 
                    error: error.message,
                    stack: error.stack 
                });
                throw error;
            }
        }
        return this;
    }

    async get(key) {
        if (!this.healthy) {
            logger.debug('Cache get skipped - unhealthy connection');
            return null;
        }

        try {
            const fullKey = `${cacheConfig.defaults.prefix}${key}`;
            const data = await this.client.get(fullKey);
            
            if (!data) {
                logger.debug(`Cache miss for key: ${fullKey}`);
                return null;
            }
            
            logger.debug(`Cache hit for key: ${fullKey}`);
            return JSON.parse(data);
        } catch (error) {
            logger.error('Cache get operation failed', { 
                key,
                error: error.message,
                stack: error.stack 
            });
            return null;
        }
    }

    async set(key, value, ttl = cacheConfig.defaults.ttl) {
        if (!this.healthy) {
            logger.debug('Cache set skipped - unhealthy connection');
            return false;
        }

        try {
            const fullKey = `${cacheConfig.defaults.prefix}${key}`;
            await this.client.setEx(fullKey, ttl, JSON.stringify(value));
            logger.debug(`Cache set successful for key: ${fullKey} (TTL: ${ttl}s)`);
            return true;
        } catch (error) {
            logger.error('Cache set operation failed', { 
                key,
                error: error.message,
                stack: error.stack 
            });
            return false;
        }
    }

    async delete(key) {
        if (!this.healthy) {
            logger.debug('Cache delete skipped - unhealthy connection');
            return false;
        }

        try {
            const fullKey = `${cacheConfig.defaults.prefix}${key}`;
            const result = await this.client.del(fullKey);
            logger.debug(`Cache delete for key: ${fullKey} - ${result} items removed`);
            return result > 0;
        } catch (error) {
            logger.error('Cache delete operation failed', { 
                key,
                error: error.message 
            });
            return false;
        }
    }

    async clear() {
        if (!this.healthy) {
            logger.debug('Cache clear skipped - unhealthy connection');
            return false;
        }

        try {
            await this.client.flushDb();
            logger.info('Cache cleared successfully');
            return true;
        } catch (error) {
            logger.error('Cache clear operation failed', { 
                error: error.message 
            });
            return false;
        }
    }

    async healthCheck() {
        try {
            await this.client.ping();
            this.healthy = true;
            return true;
        } catch (error) {
            this.healthy = false;
            return false;
        }
    }

    async disconnect() {
        try {
            await this.client.quit();
            this.connected = false;
            this.healthy = false;
            logger.info('CacheManager disconnected from Redis');
            return true;
        } catch (error) {
            logger.error('CacheManager disconnection failed', { 
                error: error.message 
            });
            return false;
        }
    }
}

// Singleton instance with immediate connection
const cacheManager = new CacheManager();

// Connect with retry logic
const maxRetries = 3;
let attempts = 0;

const connectWithRetry = async () => {
    try {
        await cacheManager.connect();
    } catch (error) {
        attempts++;
        if (attempts < maxRetries) {
            logger.warn(`CacheManager connection attempt ${attempts} failed, retrying...`);
            setTimeout(connectWithRetry, 1000 * attempts);
        } else {
            logger.error('CacheManager failed to connect after maximum retries');
            process.exit(1);
        }
    }
};

await connectWithRetry();

export { cacheManager };