import os from 'os';
import { logger } from './logger.js';

export const getSystemStats = async () => {
    try {
        return {
            memory: {
                total: os.totalmem(),
                free: os.freemem(),
                usage: ((os.totalmem() - os.freemem()) / os.totalmem()) * 100
            },
            cpu: {
                cores: os.cpus().length,
                load: os.loadavg()
            },
            network: Object.values(os.networkInterfaces())
                .flat()
                .filter(i => i && !i.internal)
        };
    } catch (error) {
        logger.error('Failed to get system stats', { error });
        return {};
    }
};

export const monitorSystem = () => {
    setInterval(async () => {
        const stats = await getSystemStats();
        logger.debug('System monitoring', { stats });
    }, 60000); // Every minute
};