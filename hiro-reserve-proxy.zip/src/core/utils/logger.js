import winston from 'winston';
import { createClient } from 'redis';
import RedisTransport from 'winston-redis';

const { combine, timestamp, json } = winston.format;

// Create Redis client for logging
const redisClient = createClient({
    url: process.env.REDIS_LOG_URL || 'redis://localhost:6379/1'
});
await redisClient.connect();

const logger = winston.createLogger({
    level: 'info',
    format: combine(
        timestamp(),
        json()
    ),
    transports: [
        new winston.transports.Console(),
        new RedisTransport({
            client: redisClient,
            level: 'info',
            key: 'khirox:logs'
        })
    ],
    exceptionHandlers: [
        new winston.transports.File({ filename: 'logs/exceptions.log' })
    ]
});

export { logger };