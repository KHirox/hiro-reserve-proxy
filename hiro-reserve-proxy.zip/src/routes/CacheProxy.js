import { Router } from 'express';
import fetch from 'node-fetch';
import { Agent } from 'https';
import { performance } from 'perf_hooks';
import { memoryUsage } from 'node:process';
import { cacheManager } from '../core/cache/manager.js';
import { logger } from '../core/utils/logger.js';

const router = Router();
const BLACKLIST = [
  "samurai_lps.xml", "golem_of_lago.xml", 
  "mario_smh.xml", "hta_weapon.xml",
  "alucard.xml", "buster_ic.xml",
  "sonic_ic.xml", "cat_ic.xml"
];

router.get('/:ip/cache/*', async (req, res, next) => {
  const startTime = performance.now();
  
  // IP validation
  if (!/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(req.params.ip)) {
    return next();
  }

  // Blacklist check
  if (BLACKLIST.some(item => req.originalUrl.includes(item))) {
    logger.warn(`Blocked blacklisted URL: ${req.originalUrl}`);
    return res.status(403).json({ 
      error: 'Access Denied', 
      code: 'BLACKLISTED_RESOURCE' 
    });
  }

  try {
    // Cache check
    const cacheKey = `proxy:${req.method}:${req.originalUrl}`;
    const cached = await cacheManager.get(cacheKey);
    
    if (cached) {
      logger.debug(`Cache hit for ${cacheKey}`);
      return res
        .status(cached.status)
        .set(cached.headers)
        .send(cached.body);
    }

    // Proxy request
    const agent = new Agent({ rejectUnauthorized: false });
    const headers = { 
      ...req.headers, 
      host: 'www.growtopia1.com',
      'x-forwarded-for': req.ip,
      'x-khirox-proxy': '1.0'
    };

    delete headers['content-length'];
    delete headers['transfer-encoding'];

    const response = await fetch(`https:/${req.originalUrl}`, {
      method: req.method,
      headers,
      agent,
      redirect: 'manual'
    });

    // Prepare response
    const responseHeaders = {};
    for (const [key, value] of response.headers) {
      if (!['content-length', 'transfer-encoding'].includes(key.toLowerCase())) {
        responseHeaders[key] = value;
      }
    }

    const body = await response.buffer();
    const responseData = {
      status: response.status,
      headers: responseHeaders,
      body,
      ttl: 3600 // 1 hour
    };

    // Cache successful responses
    if (response.ok) {
      await cacheManager.set(cacheKey, responseData);
    }

    // Send response
    res
      .status(response.status)
      .set(responseHeaders)
      .send(body);

    // Log performance
    const memUsage = memoryUsage();
    logger.info(`Proxied ${req.originalUrl} in ${(performance.now() - startTime).toFixed(2)}ms`, {
      memory: `${(memUsage.rss / 1024 / 1024).toFixed(2)}MB`,
      status: response.status
    });

  } catch (error) {
    logger.error(`Proxy error for ${req.originalUrl}: ${error.message}`, {
      stack: error.stack
    });
    next(error);
  }
});

export default router;