import { Router } from 'express';
import { version } from '../../package.json';
import { getSystemStats } from '../core/utils/system.js';

const router = Router();

router.get('/', async (req, res) => {
    const stats = await getSystemStats();
    res.json({
        service: 'KHirox Reverse Proxy',
        version,
        status: 'operational',
        uptime: process.uptime(),
        ...stats
    });
});

// Health check endpoint
router.get('/health', (req, res) => {
    res.status(200).json({ status: 'healthy' });
});

export default router;