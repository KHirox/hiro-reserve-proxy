import { logger } from '../core/utils/logger.js';

export const errorHandler = (err, req, res, next) => {
    const statusCode = err.statusCode || 500;
    const message = statusCode === 500 ? 'Internal Server Error' : err.message;
    
    logger.error('Request error', {
        error: err.message,
        stack: err.stack,
        url: req.originalUrl,
        method: req.method,
        status: statusCode
    });

    res.status(statusCode).json({
        error: message,
        code: err.code || 'UNKNOWN_ERROR',
        ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
    });
};